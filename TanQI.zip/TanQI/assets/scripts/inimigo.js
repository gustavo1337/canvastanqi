class Inimigo {

	//Método construtor onde especificamos algumas váriaveis utilizadas para a criação
	constructor(){
		this.posX = 0;
		this.posY = 0;
		this.largura = 60;
		this.altura = 30;
		this.anguloInicial = 1.23 * Math.PI;
		this.anguloFinal = 0.81 * Math.PI;
		this.raio = (Math.round(this.altura * 0.3));
		this.pixel_por_segundo = 220;
	}

	//Junta todas as outras funções e realiza o carregamento dos métodos para exibir tudo funcionando
	exibirTanqueInimigo(diferencaTempo){
		this.movimentarTanqueInimigo(diferencaTempo);
		ctx.beginPath();
		this.desenhar();
		this.colidirComVeiculo();
		this.verificarInvasao()
	}

	//Movimentar tanque de acordo com os botões pressionados
	movimentarTanqueInimigo(diferencaTempo){
		var taxaMovimentacao = (diferencaTempo / 1000) * this.pixel_por_segundo;

		if(this.posX <= 0 || this.posY <= 52){
			this.posX = canvas.width;
			this.posY = 445 * Math.random();
		}else{
			this.posX -= taxaMovimentacao;
		}
	}

	//Verifica se houve uma colisão com o veiculo
	colidirComVeiculo(){
		if((this.posY > (veiculo.posY - veiculo.altura) + 15 && this.posY < veiculo.posY + veiculo.altura) && (this.posX < veiculo.posX + veiculo.largura && this.posX > (veiculo.posX - veiculo.largura) +25)){
			veiculo.qtd_vidas--;
			this.posX = canvas.width;
			this.posY = 445 * Math.random();
			veiculo.posX = 58;
			veiculo.posY = canvas.height / 2;
		}
	}

	//Verifica se o tanque inimigo atingiu a base
	verificarInvasao(){
		if(this.posX <= 0){
			veiculo.qtd_vidas--;
		}
	}

	//Desenhar o tanque inimigo
	desenhar(){
		//Corpo do tanque inimigo
		ctx.beginPath();
		ctx.rect(this.posX, this.posY, this.largura, this.altura);
		ctx.fillStyle = "#8B814C";
		ctx.fill();

		//Canhão
		ctx.beginPath();
		ctx.arc(this.posX + Math.round(this.largura * 0.7), this.posY + Math.round(this.altura * 0.5), this.raio, this.anguloInicial, this.anguloFinal);
		ctx.lineTo(this.posX + Math.round(this.largura * 0.2), this.posY + Math.round(this.altura * 0.65));
		ctx.lineTo(this.posX + Math.round(this.largura * 0.2), this.posY + Math.round(this.altura * 0.3));
		ctx.closePath();
		ctx.fillStyle = "#000";
		ctx.fill();
	}
}
