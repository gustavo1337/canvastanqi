class Veiculo{

//Método construtor onde especificamos algumas váriaveis utilizadas para a criação
	constructor(){
		this.posX = 57;
		this.posY = canvas.height / 2;
		this.largura = 80;
		this.altura = 50;
		this.anguloInicial = 0.14 * Math.PI;
		this.anguloFinal = 1.8 * Math.PI;
		this.raio = (Math.round(this.altura * 0.2));
		this.qtd_vidas = 5;
		this.pontuacao = "000";
		this.pixel_por_segundo = 190;
		this.taxa_de_tiros = 40;
		this.proximo_tiro = 0;
	}

	//Junta todas as outras funções e realiza o carregamento dos métodos para exibir tudo funcionando
	exibirTanque(diferencaTempo){
		this.movimentarTanque(diferencaTempo);
		ctx.beginPath();
		this.desenhar();
		this.verificarVidas();
	}

	//Movimentar tanque de acordo com os botões pressionados e disparar se a tecla espaço for pressionada
	movimentarTanque(diferencaTempo){
		var taxaMovimentacao = (diferencaTempo / 1000) * this.pixel_por_segundo;

		if(botoes.cima){
			if(this.posY >= 48){
				this.posY -= taxaMovimentacao;
			}
		}

		if(botoes.baixo){
			if(this.posY <= (canvas.height - 55)){
				this.posY += taxaMovimentacao;
			}
		}

		if(botoes.esquerda){
			if(this.posX >= 57){
				this.posX -= taxaMovimentacao;
			}
		}

		if(botoes.direita){
			if(this.posX <= (canvas.width - 100)){
				this.posX += taxaMovimentacao;
			}
		}

		if (botoes.espaco) {
			this.proximo_tiro += diferencaTempo / 10;
			if (this.proximo_tiro >= this.taxa_de_tiros) {
				let cordenadas_bola = {};
				cordenadas_bola.x = this.posX + 108;
				cordenadas_bola.y = this.posY + (this.altura / 2);
				bolas_canhao_desenhadas.push(new Bola_Canhao(cordenadas_bola));
				this.proximo_tiro = 0;
			}
		}
	}

	//Verifica quando as vidas disponiveis se esgotarem
	verificarVidas(){
		if(this.qtd_vidas == 0){
			alert('Fim de jogo !\nPontuação obtida: '+veiculo.pontuacao+' pontos !\nClique em OK para reiniciar o jogo.');
			window.location.reload();
		}
	}

	//Desenha todos os elementos da classe Veiculo
	desenhar(){
		//Área dos marcadores
		ctx.beginPath();
		ctx.rect(0, 0, canvas.width, 45);
		ctx.fillStyle = "#B22222";
		ctx.fill();

		//Vidas
		ctx.beginPath();
		ctx.fillStyle = '#000';
		ctx.font = '32px Candara';
		ctx.fillText("Vidas: "+this.qtd_vidas, 10, 32);

		//Pontos
		ctx.beginPath();
		ctx.fillStyle = '#000';
		ctx.font = '32px Candara';
		ctx.fillText("Pontos: "+this.pontuacao, 424, 32);

		//Corpo do tanque
		ctx.beginPath();
		ctx.rect(this.posX, this.posY, this.largura, this.altura);
		ctx.fillStyle = "#000";
		ctx.fill();

		//Canhão
		ctx.beginPath();
		ctx.arc(this.posX + Math.round(this.largura * 0.4), this.posY + Math.round(this.altura * 0.5), this.raio, this.anguloInicial, this.anguloFinal);
		ctx.lineTo(this.posX + Math.round(this.largura * 1.20), this.posY + Math.round(this.altura * 0.38));
		ctx.lineTo(this.posX + Math.round(this.largura * 1.20), this.posY + Math.round(this.altura * 0.60));
		ctx.closePath();
		ctx.fillStyle = "#8B814C";
		ctx.fill();

		//Desenhar a área que deve ser defendida pelo tanque
		ctx.beginPath();
		ctx.rect(0, 45, 54, 435);
		ctx.fillStyle = "#1E90FF";
		ctx.fill();
	}
}
