class Bola_Canhao{

	//Método construtor onde especificamos algumas váriaveis utilizadas para a criação
	constructor(cordenadas_bola){
		this.posX = cordenadas_bola.x;
		this.posY = cordenadas_bola.y;
		this.cor = '#000';
		this.pixel_por_segundo = 210;
	}

	//Junta todas as outras funções e realiza o carregamento dos métodos para exibir tudo funcionando
	animarBola(diferencaTempo){
		this.movimentarBola(diferencaTempo);
		this.desenhar();
		this.atingirInimigo();
		this.concluirTrajeto();
	}

	//Faz a bola se movimentar
	movimentarBola(diferencaTempo){
		let taxaMovimentacao = (diferencaTempo / 1000) * this.pixel_por_segundo;
		this.posX += taxaMovimentacao;
	}

	//Verifica se a bola concluiu o trajeto
	concluirTrajeto(){
		return this.posX <= -108;
	}

	//Verifica se houve colisão com o inimigo
	atingirInimigo(){
		if((this.posY > inimigo.posY - inimigo.altura +15 && this.posY < inimigo.posY + inimigo.altura + 30) && (this.posX < inimigo.posX + inimigo.largura && this.posX > inimigo.posX - inimigo.largura + 45)){
			 veiculo.pontuacao++;
			 this.posX = -108;
			 inimigo.posX = canvas.width;
			 inimigo.posY = 445 * Math.random();
		}
	}

	//Desenhar as bolas de canhão
	desenhar(){
		var anguloInicial = 0;
		var anguloFinal = 2 * Math.PI;
		var raio = 8;

		ctx.beginPath();
		ctx.fillStyle = this.cor;
		ctx.arc(this.posX, this.posY, raio, anguloInicial, anguloFinal);
		ctx.fill();
	}
}
