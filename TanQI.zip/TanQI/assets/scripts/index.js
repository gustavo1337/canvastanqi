//Definindo o elemento canvas
var canvas = document.getElementById('single-player-game');
var ctx = canvas.getContext('2d');

//Obtendo os frames dos navegadores
window.requestAnimFrame = (function(callback){
	return window.requestAnimationFrame
	||window.webkitRequestAnimationFrame
	||window.mozRequestAnimationFrame
	||window.oRequestAnimationFrame
	||window.msRequestAnimationFrame
	||function (callback){
		window.setTimeout (callback, 1000 / 60);
	};
})();

//Importando classes
var botoes = new Botoes();
var inimigo = new Inimigo();
var veiculo = new Veiculo();
var bolas_canhao_desenhadas = [];

//Adicionando eventos quando os botões forem pressionados
window.addEventListener("keydown", function(e) {botoes.botaoPressionado(e);}, true);
window.addEventListener("keyup", function(e) {botoes.botaoSolto(e);}, true);

//Função responsável pelo ciclo de animação do jogo
function animar(canvas, ctx, tempoInicial, tempoAnterior){
	var tempoAtual = (new Date()).getTime();
	var diferencaTempo = tempoAtual - tempoAnterior;
	ctx.clearRect(0, 0, canvas.width, canvas.height);
	veiculo.exibirTanque(diferencaTempo);
	inimigo.exibirTanqueInimigo(diferencaTempo);

	for(let i = 0; i < bolas_canhao_desenhadas.length; i++){
		bolas_canhao_desenhadas[i].animarBola(diferencaTempo);
		if(bolas_canhao_desenhadas[i].concluirTrajeto()){
			bolas_canhao_desenhadas.splice(i, 1);
		}
	}

	requestAnimFrame(function(){
		animar(canvas, ctx, tempoAtual, tempoInicial);
	});
}

var tempoInicial = (new Date()).getTime();
animar(canvas, ctx, tempoInicial, tempoInicial);
