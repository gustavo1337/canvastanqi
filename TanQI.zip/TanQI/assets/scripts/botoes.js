class Botoes {

	//Método construtor onde especificamos algumas váriaveis utilizadas para a criação
	constructor() {
		this.cima = false;
		this.baixo = false;
		this.esquerda = false;
		this.direita = false;
		this.espaco = false;
	}

	//Verifica se alguma das teclas está pressionada
	botaoPressionado(e) {
		this.alterarBotao(e, true);
	}

	//Verifica se alguma das teclas está solta
	botaoSolto(e) {
		this.alterarBotao(e, false);
	}

	//Define as teclas utilizando código ASCII e as variáveis do construtor como referências
	alterarBotao(input, bool) {
		var botao = input.keyCode;

		if (botao == 87) {
			this.cima = bool;
		}
		if (botao == 83) {
			this.baixo = bool;
		}
		if (botao == 65) {
			this.esquerda = bool;
		}
		if (botao == 68) {
			this.direita = bool;
		}
		if (botao == 32) {
			this.espaco = bool;
		}
	}
}
