$(document).ready(function(){

	$("#b1").click(function(){

		$("#menu-principal").css("display","none");
		$("#modos-jogo").css("display","block");

	});

	$("#b2").click(function(){

		$("#menu-principal").css("display","none");
		$("#bloco-instrucoes").css("display","block");

	});

	$("#b3").click(function(){

		$("#menu-principal").css("display","none");
		$("#bloco-sobre").css("display","block");

	});

	$("#b4").click(function(){

		$("#menu-principal").css("display","none");
		$("#bloco-creditos").css("display","block");

	});

});

function atualizaPage(){
	window.location.reload();
}

function cliqueSinglePlayer(){
	alert("Bem-Vindo ao TanQI !\nSe você já conheceu o nosso jogo clique em OK e já saia jogando !\nDivirta-se !")
	window.open('singleplayer.html');
}

function cliqueMultiplayer(){
	alert('Desculpe-nos\nO modo multiplayer não está disponivel atualmente !');
}
